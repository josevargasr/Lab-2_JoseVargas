/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg2_josevargas;
import java.util.Random;
/**
 *
 * @author josevargas
 */
public class Personajes {
    static Random r = new Random();
    private String tipo;
    private String nombre;
    private String raza;
    private double estatura;
    private int peso;
    private int edad;
    private String descripcion;
    private String nacionalidad;
    private int hp;
    private int cs;
    private int ac;
    private int dg;
    
    public Personajes(){
        
    }
    
    public Personajes(String tipo, String nombre, String raza, double estatura, int peso, int edad, String descripcion, String nacionalidad){
        this.tipo = tipo;
        this.nombre = nombre;
        this.raza = raza;
        this.estatura = estatura;
        this.peso = peso;
        this.edad = edad;
        this.descripcion = descripcion;
        this.nacionalidad = nacionalidad;
        sethp();
        setcs();
        setac();
        setdg();       
    }
    
    public String gettipo(){
        return this.tipo;
    }
    
    public void settipo(String tipo){
        this.tipo = tipo;
    }
    
    public String getnombre(){
        return this.nombre;
    }
    
    public void setnombre(String nombre){
        this.nombre = nombre;
    }
    
    public String getraza(){
        return this.raza;
    }
    
    public void setraza(String raza){
        this.raza = raza;
    }
    
    public double getestatura(){
        return this.estatura;
    }
    
    public void setestatura(double estatura){
        this.estatura = estatura;
    }
    
    public int getpeso(){
        return this.peso;
    }
    
    public void setpeso(int peso){
        this.peso = peso;
    }
    
    public int getedad(){
        return this.edad;
    }
    
    public void setedad(int edad){
        this.edad = edad;
    }
    
    public String getdescripcion(){
        return this.descripcion;
    }
    
    public void setdescripcion(String descripcion){
        this.descripcion = descripcion;
    }
    
    public String getnacionalidad(){
        return this.nacionalidad;
    }
    
    public void setnacionalidad(String nacionalidad){
        this.nacionalidad = nacionalidad;
    }
    
    public int gethp(){
        return this.hp;
    }
    
    public void sethp(){
        if(this.raza.equals("Mediano")){
            hp = 50 + r.nextInt(10);
        }else if(this.raza.equals("Enano")){
            hp = 80 + r.nextInt(20);
        }else if(this.raza.equals("Elfo")){
            hp = 50 + r.nextInt(30);
        }else if(this.raza.equals("Humano")){
            hp = 40 + r.nextInt(35);
        }
    }
    
    public int getcs(){
        return this.cs;
    }
    
    public void setcs(){
         if(this.tipo.equals("Clerigo")){
            cs = 97;
        }else if(this.tipo.equals("Barbaro")){
            cs = 93;
        }else if(this.tipo.equals("Mago")){
            cs = 101;
        }else if(this.tipo.equals("Picaro")){
            cs = 80;
        }
    }
    
    public int getac(){
        return this.ac;
    }
    
    public void setac(){
        if(this.tipo.equals("Clerigo")){
            ac = 40;
        }else if(this.tipo.equals("Barbaro")){
            ac = 65;
        }else if(this.tipo.equals("Mago")){
            ac = 20;
        }else if(this.tipo.equals("Picaro")){
            ac = 50;
        }
    }
    
    public int getdg(){
        return this.dg;
    }
    
    public void setdg(){
         if(this.tipo.equals("Clerigo")){
            dg = 5 + r.nextInt(10);
        }else if(this.tipo.equals("Barbaro")){
            dg = 15 + r.nextInt(15);
        }else if(this.tipo.equals("Mago")){
            dg = 5 + r.nextInt(5);
        }else if(this.tipo.equals("Picaro")){
            dg = 15 + r.nextInt(10);
        }
    }
    
    @Override
    public String toString(){
        return "Nombre: " + nombre + " | " + "Tipo: " + tipo + " | " + "Raza: " + raza + " | " + "Estatura: " + estatura + " | " + "Peso: " + peso + " | " + "Edad: " + edad + " | " + "Descripcion: " + descripcion + " | " +  "Nacionalidad: " + nacionalidad + " | " +  "HealthPoints(HP): " + hp + " | " +  "CriticStrike(CS): " + cs + " | " +  "ArmorClass(AC): " + ac +  " | " + "Damage(DG): " + dg;
    }
    
}
