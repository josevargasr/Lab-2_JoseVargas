/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg2_josevargas;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Random;
import java.util.Set;

/**
 *
 * @author josevargas
 */
public class Lab2_JoseVargas {
static Scanner entrada = new Scanner(System.in);
static Random r = new Random();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int valid=0;
        ArrayList <Personajes> lista = new ArrayList();
        lista.add(new Personajes("Barbaro", "Jordan", "Humano", 1.75, 170, 45, "Demasiado rudo", "Norfair"));
        lista.add(new Personajes("Mago", "Wizza", "Enano", 1.01, 50, 120, "Bien pequeño", "Brinstar"));
        lista.add(new Personajes("Clerigo", "G-Sus", "Mediano", 1.79, 157, 2020, "Muy poderoso", "Zebes"));
        lista.add(new Personajes("Picaro", "El Bromas", "Elfo", 1.20, 80, 150, "Un elfo travieso", "Maridia"));
        while(valid==0){
            System.out.println("-----Codes-----");
            System.out.println("1] Creacion de Personajes");
            System.out.println("2] Modificacion de Personajes");
            System.out.println("3] Ver Atributos de Personajes");
            System.out.println("4] Eliminar Personajes");
            System.out.println("5] Combate");
            System.out.println("6] Salir");
            int opcion = entrada.nextInt();
            switch(opcion){
                case 1:
                    System.out.println("Ingrese el tipo de personaje que desea [Clerigo, Barbaro, Mago, Picaro]: ");
                    String tipo = entrada.next();
                    System.out.println("Ingrese el nombre de su personaje: ");
                    String nombre = entrada.next();
                    System.out.println("Ingrese la raza de su personaje [Mediano, Enano, Elfo, Humano]: ");
                    String raza = entrada.next();
                    System.out.println("Ingrese la estatura de su personaje: ");
                    double estatura = entrada.nextDouble();
                    System.out.println("Ingrese el peso de su personaje: ");
                    int peso = entrada.nextInt();
                    System.out.println("Ingrese la edad de su personaje: ");
                    int edad = entrada.nextInt();
                    System.out.println("Ingrese la descripcion de su personaje: ");
                    String descripcion = entrada.nextLine();
                    descripcion = entrada.nextLine();
                    System.out.println("Ingrese la nacionalidad de su personaje [Norfair, Brinstar, Maridia, Zebes, Crateria]: ");
                    String nacionalidad = entrada.next();
                    lista.add(new Personajes(tipo, nombre, raza, estatura, peso, edad, descripcion, nacionalidad));
                    System.out.println("Personaje agregado con exito!");
                    System.out.println(lista.get(lista.size()-1));
                    System.out.println();
                    break;
                case 2:
                    for (Object o : lista) {
                        System.out.println("[Personaje " + lista.indexOf(o) + "]" + o);
                    }
                    System.out.println("Ingrese al personaje que desea modificar: ");
                    int modif = entrada.nextInt();
                    System.out.println("Ingrese el tipo de personaje que desea [Clerigo, Barbaro, Mago, Picaro]: ");
                    String tip = entrada.next();
                    lista.get(modif).settipo(tip);
                    System.out.println("Ingrese el nombre de su personaje: ");
                    String nombr = entrada.next();
                    lista.get(modif).setnombre(nombr);
                    System.out.println("Ingrese la raza de su personaje [Mediano, Enano, Elfo, Humano]: ");
                    String raz = entrada.next();
                    lista.get(modif).setraza(raz);
                    System.out.println("Ingrese la estatura de su personaje: ");
                    double estatur = entrada.nextDouble();
                    lista.get(modif).setestatura(estatur);
                    System.out.println("Ingrese el peso de su personaje: ");
                    int pes = entrada.nextInt();
                    lista.get(modif).setpeso(pes);
                    System.out.println("Ingrese la edad de su personaje: ");
                    int eda = entrada.nextInt();
                    lista.get(modif).setedad(eda);
                    System.out.println("Ingrese la descripcion de su personaje: ");
                    String descripcio = entrada.nextLine();
                    descripcio = entrada.nextLine();
                    lista.get(modif).setdescripcion(descripcio);
                    System.out.println("Ingrese la nacionalidad de su personaje [Norfair, Brinstar, Maridia, Zebes, Crateria]: ");
                    String nacionalida = entrada.next();
                    lista.get(modif).setnacionalidad(nacionalida);
                    System.out.println("Personaje modificado con exito!");
                    System.out.println();
                    break;
                case 3:
                    for (Object o : lista) {
                        System.out.println("[Personaje " + lista.indexOf(o) + "]" + o);
                    }
                    System.out.println();
                    break;
                case 4:
                    for (Object o : lista) {
                        System.out.println("[Personaje " + lista.indexOf(o) + "]" + o);
                    }
                    System.out.println("Ingrese al personaje que desea eliminar: ");
                    int elim = entrada.nextInt();
                    lista.remove(elim);
                    System.out.println("Personaje eliminado con exito!");
                    System.out.println();
                    break;
                case 5:
                    for (Object o : lista) {
                        System.out.println("[Personaje " + lista.indexOf(o) + "]" + o);
                    }
                    System.out.println("Ingrese al personaje para el jugador 1: ");
                    int jug1 = entrada.nextInt();
                    System.out.println("Ingrese al personaje para el CPU: ");
                    int cpu = entrada.nextInt();
                    boolean dead = false;
                    int damage1= lista.get(jug1).getdg();
                    int damage2= lista.get(cpu).getdg();
                    int vida1 = lista.get(jug1).gethp();
                    int vida2 = lista.get(cpu ).gethp();
                    System.out.println("Vida del Jugador: " + vida1);
                    System.out.println("Vida del CPU: " + vida2);
                    while(dead == false){
                        System.out.println("Turno del Jugador");
                        System.out.println("---Acciones---:");
                        System.out.println("1] Atacar");
                        System.out.println("2] Defender");
                        int opc = entrada.nextInt();
                        if(opc == 1){
                            int attack = 1 + r.nextInt(100);
                            System.out.println("Jugador tira un golpe de " + attack);
                            if(attack > lista.get(cpu).getac()){
                                if(attack > lista.get(jug1).getcs()){
                                    vida2-= damage2 * 2;
                                }else{
                                    vida2-= damage2;
                                }
                                System.out.println("Daño provocado: " + damage1);
                                System.out.println("Vida del CPU: " + vida2);
                            }else{
                                System.out.println("Jugador no acerto!");
                            }
                        }else{
                            System.out.println("Jugador obtiene un +15 de AC");
                        }
                        if(vida2<0){
                            System.out.println("El Jugador gano!");
                            dead =true;
                        }else{
                            System.out.println("Turno del CPU");
                            System.out.println("---Acciones---:");
                            System.out.println("1] Atacar");
                            System.out.println("2] Defender");
                            int opc2 = entrada.nextInt();
                            if(opc2 == 1){
                                int attack = 1 + r.nextInt(100);
                                System.out.println("CPU tira un golpe de " + attack);
                                if(attack > lista.get(jug1).getac()){
                                    if(attack > lista.get(cpu).getcs()){
                                        vida1-= damage2 * 2;
                                    }else{
                                        vida1-= damage2;
                                    }
                                    System.out.println("Daño provocado: " + damage2);
                                    System.out.println("Vida del Jugador: " + vida1);
                                }else{
                                    System.out.println("CPU no acerto!");
                                }
                            }else{
                                System.out.println("Jugador obtiene un +15 de AC");
                            }
                        }
                        if(vida1<0){
                            System.out.println("El CPU gano!");
                            dead =true;
                        }
                    }
                    System.out.println();
                    break;
                case 6:
                    System.out.println("Gracias por jugar!");
                    System.exit(0);
                    break;
            }
        }
    }
    
}
